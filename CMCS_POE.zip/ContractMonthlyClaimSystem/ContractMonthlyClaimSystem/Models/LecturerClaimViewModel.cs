﻿namespace ContractMonthlyClaimSystem.Models
{
    using System.ComponentModel.DataAnnotations;

    public class LecturerClaimViewModel
    {
        public int LecturerId { get; set; }

        [Required]
        [Range(1, 100)]
        public int HoursWorked { get; set; }

        [Required]
        [Range(50, 500)]
        public decimal HourlyRate { get; set; }

        public decimal TotalPayment => HoursWorked * HourlyRate;

        public string Notes { get; set; }
    }

}

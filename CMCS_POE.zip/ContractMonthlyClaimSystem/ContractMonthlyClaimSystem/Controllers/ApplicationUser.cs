﻿namespace ContractMonthlyClaimSystem.Controllers
{
    public class ApplicationUser
    {
        public string UserName { get; set; }
        public string Email { get; set; }

    }
}
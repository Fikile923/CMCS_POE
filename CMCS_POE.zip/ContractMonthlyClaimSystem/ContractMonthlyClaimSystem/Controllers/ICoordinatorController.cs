﻿using Microsoft.AspNetCore.Mvc;

namespace ContractMonthlyClaimSystem.Controllers
{
    public interface ICoordinatorController
    {
        IActionResult ApproveClaim(int id);
        IActionResult PendingClaims();
        IActionResult RejectClaim(int id);
    }
}
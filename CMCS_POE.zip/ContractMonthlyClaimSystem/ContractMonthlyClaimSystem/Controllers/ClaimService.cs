﻿namespace ContractMonthlyClaimSystem.Controllers
{
    internal class ClaimService
    {
    }
}
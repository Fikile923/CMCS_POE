﻿using Microsoft.AspNetCore.Mvc;

namespace ContractMonthlyClaimSystem.Controllers
{
    public class LecturerController : Controller
    {
        private readonly ApplicationDbContext _context;

        public LecturerController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult SubmitClaim()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SubmitClaim(LecturerClaimViewModel model)
        {
            if (ModelState.IsValid)
            {
                var claim = new Claim
                {
                    LecturerId = model.LecturerId,
                    HoursWorked = model.HoursWorked,
                    HourlyRate = model.HourlyRate,
                    TotalPayment = model.HoursWorked * model.HourlyRate,
                    Status = "Pending",
                    Notes = model.Notes
                };

                _context.Claims.Add(claim);
                _context.SaveChanges();

                return RedirectToAction("ClaimSubmitted");
            }
            return View(model);
        }

        public IActionResult ClaimSubmitted()
        {
            return View();
        }
    }
}
